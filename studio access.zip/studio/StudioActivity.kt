package com.shen.studio

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

/**

- ☬SHΞN™ Studio — Main chat integration example.
- 
- این کلاس فقط نشان می‌دهد که چطور به اپ اصلی (fork خودتان) وصل شود:
- 
- 1. system prompt پایه را از اپ اصلی بگیرید
- 2. از StudioInjector بگذرانید
- 3. به API چت بفرستید
- 4. اگر پاسخ شامل panel بود، StudioWebViewHandler.showPanel(...)
- 
- اینجا فقط skeleton است — در fork خودتان جایگزین کنید.
*/
class StudioActivity : Activity() {

override fun onCreate(savedInstanceState: Bundle?) {
super.onCreate(savedInstanceState)
val tv = TextView(this).apply {
text = "☬ Studio is wired. Open Settings to enter keys."
setPadding(48, 48, 48, 48)
}
setContentView(tv)
}

// ─── نمونه‌ی اتصال به حلقه‌ی چت ────────────────────────────

fun onBeforeSendChat(userMessage: String, baseSystemPrompt: String): String {
// مرحله ۱ — تزریق کانفیگ کاربر به system prompt
return StudioInjector.inject(this, baseSystemPrompt)
}

fun onAssistantReply(assistantReply: String) {
// مرحله ۲ — آیا شامل panel است؟
if (StudioWebViewHandler.hasPanel(assistantReply)) {
val panels = StudioWebViewHandler.extractPanels(assistantReply)
// آخرین پنل را نمایش بده
StudioWebViewHandler.showPanel(this, panels.last()) { payload ->
// مرحله ۳ — نتیجه را به‌عنوان پیام جدید به چت برگردان
// sendUserMessage("[panel-result] $payload")
}
}
}
}