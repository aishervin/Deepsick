package com.shen.studio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**

- ☬SHΞN™ Studio — Optional boot receiver.
- اگر خواستید در اولین اجرای اپ بعد از نصب، منوی Studio را نشان دهید.
*/
class StudioBootReceiver : BroadcastReceiver() {
override fun onReceive(context: Context, intent: Intent?) {
if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
// فقط یک flag برای اپ اصلی
context.getSharedPreferences("shen_studio_prefs", Context.MODE_PRIVATE)
.edit()
.putBoolean("booted", true)
.apply()
}
}
}