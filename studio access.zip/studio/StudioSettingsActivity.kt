package com.shen.studio

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

/**

- ☬SHΞN™ Studio — Settings Screen
- UI به‌صورت برنامه‌نویسی‌شده از StudioSchema ساخته می‌شود.
- بدون XML layout.
*/
class StudioSettingsActivity : Activity() {

private lateinit var root: LinearLayout
private lateinit var config: JSONObject

// رنگ‌ها
private val BG = Color.parseColor("#0d0d0d")
private val SURFACE = Color.parseColor("#161616")
private val BORDER = Color.parseColor("#262626")
private val TEXT = Color.parseColor("#f0f0f0")
private val MUTED = Color.parseColor("#888888")
private val ACCENT = Color.parseColor("#4d6bfe")
private val DANGER = Color.parseColor("#f87171")

override fun onCreate(savedInstanceState: Bundle?) {
super.onCreate(savedInstanceState)
config = StudioConfig.load(this)

val scroll = ScrollView(this).apply {
setBackgroundColor(BG)
isFillViewport = true
}
root = LinearLayout(this).apply {
orientation = LinearLayout.VERTICAL
setPadding(dp(16), dp(16), dp(16), dp(32))
}
scroll.addView(root)
setContentView(scroll)

buildHeader()
StudioSchema.SECTIONS.forEach { buildSection(it) }
buildFooter()
}

// ────────────────────────── Header ──────────────────────────

private fun buildHeader() {
val title = TextView(this).apply {
text = "☬ Studio Settings"
setTextColor(TEXT)
textSize = 20f
setTypeface(typeface, Typeface.BOLD)
}
val sub = TextView(this).apply {
text = "کلیدها فقط روی دستگاه شما ذخیره می‌شوند و در ابتدای هر چت به‌عنوان [STUDIO_CONFIG] تزریق می‌شوند."
setTextColor(MUTED)
textSize = 12f
setPadding(0, dp(4), 0, dp(16))
}
root.addView(title)
root.addView(sub)
}

// ────────────────────────── Section ──────────────────────────

private fun buildSection(spec: SectionSpec) {
val card = LinearLayout(this).apply {
orientation = LinearLayout.VERTICAL
setBackgroundColor(SURFACE)
setPadding(dp(14), dp(14), dp(14), dp(14))
layoutParams = LinearLayout.LayoutParams(
ViewGroup.LayoutParams.MATCH_PARENT,
ViewGroup.LayoutParams.WRAP_CONTENT
).apply { bottomMargin = dp(10) }
}

// header
val header = LinearLayout(this).apply {
orientation = LinearLayout.HORIZONTAL
gravity = Gravity.CENTER_VERTICAL
}
header.addView(TextView(this).apply {
text = spec.icon
textSize = 18f
})
header.addView(TextView(this).apply {
text = "  ${spec.title}"
setTextColor(TEXT)
textSize = 14f
setTypeface(typeface, Typeface.BOLD)
layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
})

// دکمه افزودن (فقط برای چند-نمونه)
if (!spec.single) {
val addBtn = Button(this).apply {
text = "+ افزودن"
setTextColor(ACCENT)
textSize = 12f
setBackgroundColor(Color.TRANSPARENT)
setPadding(dp(8), dp(4), dp(8), dp(4))
setOnClickListener { addItem(spec) }
}
header.addView(addBtn)
}
card.addView(header)

// body
val body = LinearLayout(this).apply {
orientation = LinearLayout.VERTICAL
setPadding(0, dp(8), 0, 0)
tag = "body_${spec.id}"
}
card.addView(body)

root.addView(card)
refreshSection(spec)
}

private fun refreshSection(spec: SectionSpec) {
val card = root.findViewWithTag<LinearLayout>("body_${spec.id}") ?: return
card.removeAllViews()

if (spec.single) {
val obj = config.optJSONObject(spec.id) ?: JSONObject()
config.put(spec.id, obj)
card.addView(buildItemRow(spec, obj, -1))
} else {
val arr = config.optJSONArray(spec.id) ?: JSONArray().also { config.put(spec.id, it) }
if (arr.length() == 0) {
card.addView(TextView(this).apply {
text = "خالی — روی «+ افزودن» بزنید"
setTextColor(MUTED)
textSize = 12f
setPadding(dp(4), dp(6), 0, dp(4))
})
}
for (i in 0 until arr.length()) {
val obj = arr.optJSONObject(i) ?: JSONObject()
card.addView(buildItemRow(spec, obj, i))
}
}
}

// ────────────────────────── Item Row ──────────────────────────

private fun buildItemRow(spec: SectionSpec, obj: JSONObject, idx: Int): View {
val row = LinearLayout(this).apply {
orientation = LinearLayout.VERTICAL
setBackgroundColor(Color.parseColor("#0f0f0f"))
setPadding(dp(12), dp(10), dp(12), dp(10))
layoutParams = LinearLayout.LayoutParams(
ViewGroup.LayoutParams.MATCH_PARENT,
ViewGroup.LayoutParams.WRAP_CONTENT
).apply { topMargin = dp(6) }
}

// top bar
if (!spec.single) {
val top = LinearLayout(this).apply {
orientation = LinearLayout.HORIZONTAL
gravity = Gravity.CENTER_VERTICAL
}
top.addView(TextView(this).apply {
text = "#${idx + 1}"
setTextColor(MUTED)
textSize = 11f
layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
})
top.addView(smallBtn("✎ ویرایش") { editItem(spec, idx) })
top.addView(smallBtn("↑") { moveItem(spec, idx, -1) })
top.addView(smallBtn("↓") { moveItem(spec, idx, +1) })
top.addView(smallBtn("✕", DANGER) { deleteItem(spec, idx) })
row.addView(top)
} else {
val top = LinearLayout(this).apply {
orientation = LinearLayout.HORIZONTAL
gravity = Gravity.CENTER_VERTICAL
}
top.addView(TextView(this).apply {
text = " " // فاصله
layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
})
top.addView(smallBtn("✎ ویرایش") { editItem(spec, idx) })
row.addView(top)
}

// نمایش خلاصه (فقط فیلدهای غیر-حساس)
val summary = LinearLayout(this).apply {
orientation = LinearLayout.VERTICAL
setPadding(0, dp(6), 0, 0)
}
for (f in spec.fields) {
val v = obj.optString(f.key, "")
val display = when (f.type) {
FieldType.PASSWORD -> if (v.isBlank()) "—" else mask(v)
else -> v.ifBlank { "—" }
}
val tv = TextView(this).apply {
text = "f.label:{f.label}: f.label:display"
setTextColor(if (v.isBlank()) MUTED else TEXT)
textSize = 12f
}
summary.addView(tv)
}
row.addView(summary)

return row
}

private fun smallBtn(text: String, color: Int = ACCENT, onClick: () -> Unit): Button {
return Button(this).apply {
this.text = text
setTextColor(color)
textSize = 11f
setBackgroundColor(Color.TRANSPARENT)
setPadding(dp(6), dp(2), dp(6), dp(2))
minWidth = 0; minimumWidth = 0
setOnClickListener { onClick() }
}
}

private fun mask(s: String): String {
if (s.length <= 8) return "••••"
return s.take(4) + "…" + s.takeLast(4)
}

// ────────────────────────── Item Editor Dialog ──────────────────────────

private fun editItem(spec: SectionSpec, idx: Int) {
val obj = if (spec.single) {
config.optJSONObject(spec.id) ?: JSONObject()
} else {
config.optJSONArray(spec.id)?.optJSONObject(idx) ?: JSONObject()
}

val container = LinearLayout(this).apply {
orientation = LinearLayout.VERTICAL
setPadding(dp(20), dp(16), dp(20), dp(8))
}

val inputs = mutableMapOf<String, EditText>()

for (f in spec.fields) {
container.addView(TextView(this).apply {
text = f.label
setTextColor(MUTED)
textSize = 12f
setPadding(0, dp(8), 0, dp(4))
})
val et = EditText(this).apply {
setText(obj.optString(f.key, ""))
hint = f.placeholder
setTextColor(TEXT)
setHintTextColor(Color.parseColor("#555555"))
textSize = 13f
setBackgroundColor(Color.parseColor("#0a0a0a"))
setPadding(dp(10), dp(8), dp(10), dp(8))
if (f.type == FieldType.PASSWORD)
inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
if (f.type == FieldType.TEXTAREA)
setSingleLine(false)
if (f.rtl) gravity = Gravity.RIGHT
}
container.addView(et)
inputs[f.key] = et
}

AlertDialog.Builder(this)
.setTitle("spec.icon{spec.icon} spec.icon{spec.title}")
.setView(container)
.setPositiveButton("ذخیره") { _, _ ->
for ((k, et) in inputs) obj.put(k, et.text.toString().trim())
if (spec.single) {
config.put(spec.id, obj)
} else {
config.optJSONArray(spec.id)?.put(idx, obj)
}
StudioConfig.save(this, config)
refreshSection(spec)
toast("ذخیره شد")
}
.setNegativeButton("لغو", null)
.show()
}

private fun addItem(spec: SectionSpec) {
val obj = JSONObject()
for (f in spec.fields) obj.put(f.key, defaultFor(spec.id, f.key))
val arr = config.optJSONArray(spec.id) ?: JSONArray().also { config.put(spec.id, it) }
arr.put(obj)
StudioConfig.save(this, config)
refreshSection(spec)
// بلافاصله ادیتور را باز کن
editItem(spec, arr.length() - 1)
}

private fun defaultFor(sectionId: String, fieldKey: String): String = when {
fieldKey == "model" && sectionId == "deepseek" -> "deepseek-chat"
fieldKey == "model" && sectionId == "gemini" -> "gemini-2.0-flash"
fieldKey == "model" && sectionId == "openai" -> "gpt-4o-mini"
fieldKey == "model" && sectionId == "anthropic" -> "claude-3-5-sonnet-latest"
fieldKey == "base" && sectionId == "openai" -> "https://api.openai.com/v1"
fieldKey == "label" -> "primary"
else -> ""
}

private fun moveItem(spec: SectionSpec, idx: Int, delta: Int) {
val arr = config.optJSONArray(spec.id) ?: return
val j = idx + delta
if (j < 0 || j >= arr.length()) return
val a = arr.optJSONObject(idx)!!
val b = arr.optJSONObject(j)!!
arr.put(idx, b); arr.put(j, a)
StudioConfig.save(this, config)
refreshSection(spec)
}

private fun deleteItem(spec: SectionSpec, idx: Int) {
AlertDialog.Builder(this)
.setMessage("این مورد حذف شود؟")
.setPositiveButton("حذف") { _, _ ->
val arr = config.optJSONArray(spec.id) ?: return@setPositiveButton
// حذف با بازسازی آرایه
val newArr = JSONArray()
for (i in 0 until arr.length()) if (i != idx) newArr.put(arr.get(i))
config.put(spec.id, newArr)
StudioConfig.save(this, config)
refreshSection(spec)
}
.setNegativeButton("لغو", null)
.show()
}

// ────────────────────────── Footer ──────────────────────────

private fun buildFooter() {
val btn = Button(this).apply {
text = "☬ ذخیره و بستن"
setTextColor(Color.WHITE)
textSize = 14f
setTypeface(typeface, Typeface.BOLD)
setBackgroundColor(ACCENT)
setPadding(dp(16), dp(12), dp(16), dp(12))
layoutParams = LinearLayout.LayoutParams(
ViewGroup.LayoutParams.MATCH_PARENT,
ViewGroup.LayoutParams.WRAP_CONTENT
).apply { topMargin = dp(16) }
setOnClickListener {
StudioConfig.save(this@StudioSettingsActivity, config)
toast("ذخیره شد — از این پس به هر چت تزریق می‌شود")
finish()
}
}
root.addView(btn)

val warn = TextView(this).apply {
text = "⚠ این کلیدها در ابتدای هر چت به مدل ارسال می‌شوند. اگر به کلاینت خود اطمینان ندارید، در حالت Safe Mode استفاده کنید."
setTextColor(Color.parseColor("#fbbf24"))
textSize = 11f
setPadding(0, dp(12), 0, 0)
}
root.addView(warn)
}

// ────────────────────────── Helpers ──────────────────────────

private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

private fun toast(msg: String) {
Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
}