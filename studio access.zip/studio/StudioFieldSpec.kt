package com.shen.studio

/** نوع فیلد در فرم تنظیمات */
enum class FieldType { TEXT, PASSWORD, TEXTAREA }

/** تعریف یک فیلد */
data class FieldSpec(
val key: String,
val label: String,
val type: FieldType = FieldType.TEXT,
val placeholder: String = "",
val rtl: Boolean = false
)

/** تعریف یک بخش (مثلاً GitHub، Gemini، ...) */
data class SectionSpec(
val id: String,
val icon: String,
val title: String,
val single: Boolean,   // true = فقط یک نمونه، false = چند نمونه
val fields: List<FieldSpec>
)

/** تعریف همه‌ی بخش‌ها — از همینجا فرم ساخته می‌شود */
object StudioSchema {

val SECTIONS: List<SectionSpec> = listOf(
SectionSpec("profile", "👤", "پروفایل", true, listOf(
FieldSpec("name", "نام / نام مستعار", FieldType.TEXT, "SHΞN", rtl = true),
FieldSpec("github", "یوزرنیم گیت‌هاب", FieldType.TEXT, "username"),
FieldSpec("notes", "یادداشت", FieldType.TEXTAREA, "مثلا: نیاز به پروکسی", rtl = true)
)),
SectionSpec("github", "🐙", "GitHub Accounts", false, listOf(
FieldSpec("label", "برچسب", FieldType.TEXT, "primary", rtl = true),
FieldSpec("owner", "owner", FieldType.TEXT, "username"),
FieldSpec("token", "توکن", FieldType.PASSWORD, "ghp_... یا github_pat_...")
)),
SectionSpec("deepseek", "🧠", "DeepSeek API", false, listOf(
FieldSpec("label", "برچسب", FieldType.TEXT, "primary", rtl = true),
FieldSpec("key", "کلید", FieldType.PASSWORD, "sk-..."),
FieldSpec("model", "مدل", FieldType.TEXT, "deepseek-chat")
)),
SectionSpec("gemini", "✨", "Google Gemini API", false, listOf(
FieldSpec("label", "برچسب", FieldType.TEXT, "primary", rtl = true),
FieldSpec("key", "کلید", FieldType.PASSWORD, "AIza..."),
FieldSpec("model", "مدل", FieldType.TEXT, "gemini-2.0-flash")
)),
SectionSpec("openai", "🔷", "OpenAI API", false, listOf(
FieldSpec("label", "برچسب", FieldType.TEXT, "primary", rtl = true),
FieldSpec("key", "کلید", FieldType.PASSWORD, "sk-..."),
FieldSpec("base", "Base URL", FieldType.TEXT, "https://api.openai.com/v1"),
FieldSpec("model", "مدل", FieldType.TEXT, "gpt-4o-mini")
)),
SectionSpec("anthropic", "🎭", "Anthropic Claude", false, listOf(
FieldSpec("label", "برچسب", FieldType.TEXT, "primary", rtl = true),
FieldSpec("key", "کلید", FieldType.PASSWORD, "sk-ant-..."),
FieldSpec("model", "مدل", FieldType.TEXT, "claude-3-5-sonnet-latest")
)),
SectionSpec("custom", "🔌", "سرویس سفارشی (OpenAI-compatible)", false, listOf(
FieldSpec("name", "نام", FieldType.TEXT, "OpenRouter", rtl = true),
FieldSpec("base", "Base URL", FieldType.TEXT, "https://openrouter.ai/api/v1"),
FieldSpec("key", "کلید", FieldType.PASSWORD, "sk-..."),
FieldSpec("model", "مدل", FieldType.TEXT, "model-name")
)),
SectionSpec("workers", "⚡", "Cloudflare Worker / Proxy", false, listOf(
FieldSpec("label", "برچسب", FieldType.TEXT, "proxy", rtl = true),
FieldSpec("url", "URL", FieldType.TEXT, "https://xxx.workers.dev/"),
FieldSpec("auth", "هدر احراز (اختیاری)", FieldType.PASSWORD, "Bearer xxx")
)),
SectionSpec("misc", "🧩", "سایر سرویس‌ها", false, listOf(
FieldSpec("name", "نام", FieldType.TEXT, "Discord Webhook", rtl = true),
FieldSpec("value", "مقدار / URL / توکن", FieldType.PASSWORD, "https://..."),
FieldSpec("note", "توضیح", FieldType.TEXT, "برای اطلاع‌رسانی", rtl = true)
))
)
}