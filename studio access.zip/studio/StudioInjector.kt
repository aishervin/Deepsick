package com.shen.studio

import android.content.Context

/**

- ☬SHΞN™ Studio — Prompt Injector
- این کلاس system prompt را با بلوک [STUDIO_CONFIG] می‌آمیزد.
- 
- نکته کلیدی: کلیدهای خام (raw) تزریق می‌شوند — نه ماسک‌شده.
- دلیل: مدل باید بتواند در پنل HTML از آن‌ها استفاده کند.
- پس این تزریق در دستگاه کاربر انجام می‌شود و کلید به سرور کلاینت می‌رود.
- برای محیط‌های ناامن، حالت SAFE را فعال کنید (فقط لیبل‌ها).
*/
object StudioInjector {

/** حالت امن: فقط لیبل‌ها تزریق می‌شوند، نه کلید خام */
var safeMode: Boolean = false

private const val OPEN = "[STUDIO_CONFIG]"
private const val CLOSE = "[/STUDIO_CONFIG]"

/**

- system prompt را با کانفیگ کاربر می‌آمیزد.
- اگر کانفیگ خالی باشد، prompt پایه دست‌نخورده برمی‌گردد.
*/
fun inject(ctx: Context, basePrompt: String): String {
if (StudioConfig.isEmpty(ctx)) return basePrompt

val payload = if (safeMode) buildSafePayload(ctx) else StudioConfig.load(ctx).toString()

return buildString {
appendLine(basePrompt)
appendLine()
appendLine(OPEN)
appendLine(payload)
appendLine(CLOSE)
}
}

/** فقط لیبل‌ها — بدون هیچ کلید واقعی */
private fun buildSafePayload(ctx: Context): String {
val cfg = StudioConfig.load(ctx)
val out = org.json.JSONObject()
for (s in listOf("github","deepseek","gemini","openai","anthropic","custom","workers")) {
val arr = cfg.optJSONArray(s) ?: continue
val labels = org.json.JSONArray()
for (i in 0 until arr.length()) {
val o = arr.optJSONObject(i) ?: continue
labels.put(o.optString("label").ifBlank { o.optString("name") })
}
out.put(s, labels)
}
return out.toString()
}
}