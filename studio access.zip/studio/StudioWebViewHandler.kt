package com.shen.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.webkit.*
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**

- ☬SHΞN™ Studio — WebView Panel Handler
- 
- هر بلوکی به شکل:
- ```

```
- <!DOCTYPE html>...
- ```

```
- 
- که در پاسخ مدل پیدا شود، استخراج و در یک WebView بارگذاری می‌شود.
- پل JavascriptInterface با نام StudioBridge ثبت می‌شود.
*/
object StudioWebViewHandler {

private val PANEL_REGEX = Regex(
"`html-panel\\s*\\n([\\s\\S]*?)\\n`",
RegexOption.MULTILINE
)

private val httpExecutor = Executors.newCachedThreadPool()
private val mainHandler = Handler(Looper.getMainLooper())

/** آیا متن پاسخ شامل پنل است؟ */
fun hasPanel(text: String): Boolean = PANEL_REGEX.containsMatchIn(text)

/** تمام پنل‌های موجود در متن را برمی‌گرداند */
fun extractPanels(text: String): List<String> =
PANEL_REGEX.findAll(text).map { it.groupValues[1] }.toList()

/**

- یک پنل را در یک دیالوگ WebView تمام‌صفحه نمایش می‌دهد.
- وقتی کاربر نتیجه‌ای از پنل دریافت کرد، onResult فراخوانی می‌شود.
*/
fun showPanel(activity: Activity, html: String, onResult: (String) -> Unit) {
val webView = WebView(activity).apply {
settings.javaScriptEnabled = true
settings.domStorageEnabled = true
settings.allowFileAccess = true
settings.allowContentAccess = true
settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
settings.cacheMode = WebSettings.LOAD_DEFAULT
settings.loadWithOverviewMode = true
settings.useWideViewPort = true
}

val bridge = StudioBridge(activity, webView) { payload ->
mainHandler.post { onResult(payload) }
}
webView.addJavascriptInterface(bridge, "StudioBridge")

webView.webChromeClient = object : WebChromeClient() {
override fun onConsoleMessage(m: ConsoleMessage): Boolean {
android.util.Log.d("StudioPanel", "m.message()@{m.message()} @ m.message()@{m.lineNumber()}")
return true
}
}

val container = LinearLayout(activity).apply {
orientation = LinearLayout.VERTICAL
setBackgroundColor(Color.parseColor("#0d0d0d"))
}
val header = TextView(activity).apply {
text = "  ☬ Studio Panel — در حال اجرا"
setTextColor(Color.parseColor("#888888"))
setPadding(24, 24, 24, 12)
textSize = 12f
}
container.addView(header)
container.addView(webView, LinearLayout.LayoutParams(
LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
))

val dialog = AlertDialog.Builder(activity, android.R.style.Theme_Material_NoActionBar_Fullscreen)
.setView(container)
.setNegativeButton("بستن") { _, _ -> }
.create()

dialog.setOnDismissListener { webView.destroy() }
dialog.show()

webView.loadDataWithBaseURL(
"https://studio.local/",
html,
"text/html",
"UTF-8",
null
)
}

// ═══════════════════════════════════════════════════════════
//  BRIDGE — در معرض JS قرار می‌گیرد
// ═══════════════════════════════════════════════════════════

class StudioBridge(
private val ctx: Context,
private val webView: WebView,
private val onResultCb: (String) -> Unit
) {
private fun runOnUi(block: () -> Unit) {
mainHandler.post(block)
}

@JavascriptInterface
fun getConfig(): String = StudioConfig.load(ctx).toString()

@JavascriptInterface
fun onResult(payload: String) {
runOnUi { onResultCb(payload) }
}

/** fetch بومی — CORS ندارد، Mixed Content ندارد */
@JavascriptInterface
fun fetch(url: String, method: String, headersJson: String, body: String): String {
return doRequest(url, method, headersJson, body)
}

/** از طریق Worker پروکسی می‌رود */
@JavascriptInterface
fun proxyFetch(targetUrl: String, method: String, headersJson: String, body: String): String {
val cfg = StudioConfig.load(ctx)
val workers = cfg.optJSONArray("workers") ?: return err("no worker configured")
if (workers.length() == 0) return err("no worker configured")
val w = workers.optJSONObject(0) ?: return err("worker invalid")
val base = w.optString("url").trimEnd('/')
val auth = w.optString("auth")
val full = "base/?url=base/?url=base/?url={java.net.URLEncoder.encode(targetUrl, "UTF-8")}"
val extra = JSONObject().apply {
if (auth.isNotBlank()) put("Authorization", auth)
}
return doRequest(full, method, extra.toString(), body)
}

/** میان‌بر: GitHub API با توکن ذخیره‌شده */
@JavascriptInterface
fun github(path: String, method: String, body: String): String {
val cfg = StudioConfig.load(ctx)
val arr = cfg.optJSONArray("github") ?: return err("no github account")
if (arr.length() == 0) return err("no github account")
val a = arr.optJSONObject(0)!!
val token = a.optString("token")
val headers = JSONObject().apply {
put("Authorization", "Bearer token")
             put("Accept", "application/vnd.github+json")
             put("X-GitHub-Api-Version", "2022-11-28")
         }
         val base = "https://api.github.com"
         val full = if (path.startsWith("http")) path else "basepath"}"
return doRequest(full, method.ifBlank { "GET" }, headers.toString(), body)
}

/** میان‌بر: DeepSeek chat */
@JavascriptInterface
fun deepseek(prompt: String, model: String): String {
val cfg = StudioConfig.load(ctx)
val arr = cfg.optJSONArray("deepseek") ?: return err("no deepseek key")
if (arr.length() == 0) return err("no deepseek key")
val a = arr.optJSONObject(0)!!
val key = a.optString("key")
val m = model.ifBlank { a.optString("model", "deepseek-chat") }
val headers = JSONObject().apply {
put("Authorization", "Bearer $key")
put("Content-Type", "application/json")
}
val body = JSONObject().apply {
put("model", m)
put("messages", org.json.JSONArray().apply {
put(JSONObject().apply {
put("role", "user"); put("content", prompt)
})
})
}.toString()
return doRequest("https://api.deepseek.com/chat/completions", "POST", headers.toString(), body)
}

/** میان‌بر: Gemini generateContent */
@JavascriptInterface
fun gemini(prompt: String, model: String): String {
val cfg = StudioConfig.load(ctx)
val arr = cfg.optJSONArray("gemini") ?: return err("no gemini key")
if (arr.length() == 0) return err("no gemini key")
val a = arr.optJSONObject(0)!!
val key = a.optString("key")
val m = model.ifBlank { a.optString("model", "gemini-2.0-flash") }
val headers = JSONObject().apply { put("Content-Type", "application/json") }
val body = JSONObject().apply {
put("contents", org.json.JSONArray().apply {
put(JSONObject().apply {
put("parts", org.json.JSONArray().apply {
put(JSONObject().apply { put("text", prompt) })
})
})
})
}.toString()
val url = "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key"
return doRequest(url, "POST", headers.toString(), body)
}

// ──────── HTTP native ────────

private fun doRequest(url: String, method: String, headersJson: String, body: String): String {
var conn: HttpURLConnection? = null
return try {
conn = (URL(url).openConnection() as HttpURLConnection).apply {
requestMethod = method.ifBlank { "GET" }.uppercase()
connectTimeout = 15000
readTimeout = 30000
doInput = true
if (body.isNotBlank() && requestMethod != "GET") {
doOutput = true
}
// هدرها
try {
val h = JSONObject(headersJson)
val keys = h.keys()
while (keys.hasNext()) {
val k = keys.next()
setRequestProperty(k, h.optString(k))
}
} catch (_: Exception) { /* headersJson نامعتبر → نادیده */ }
if (!requestProperties.containsKey("User-Agent")) {
setRequestProperty("User-Agent", "ShenStudio/1.0")
}
}
if (body.isNotBlank() && conn.requestMethod != "GET") {
conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
}

val code = conn.responseCode
val stream = if (code in 200..299) conn.inputStream else conn.errorStream
val text = stream?.bufferedReader()?.use(BufferedReader::readText) ?: ""
JSONObject().apply {
put("ok", code in 200..299)
put("status", code)
put("body", text)
}.toString()
} catch (e: Exception) {
err(e.message ?: "network error")
} finally {
conn?.disconnect()
}
}

private fun err(msg: String): String =
JSONObject().apply { put("ok", false); put("error", msg) }.toString()
}
}