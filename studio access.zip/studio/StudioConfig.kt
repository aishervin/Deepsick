package com.shen.studio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**

- ☬SHΞN™ Studio — local config store
- کلیدها فقط روی دستگاه کاربر می‌مانند؛ در SharedPreferences.
- تزریق به پرامپت از همین‌جا انجام می‌شود.
*/
object StudioConfig {

private const val PREF = "shen_studio_prefs"
private const val KEY_JSON = "studio_config_json"

/** ساختار پیش‌فرض خالی */
fun empty(): JSONObject = JSONObject().apply {
put("profile", JSONObject().apply {
put("name", ""); put("github", ""); put("notes", "")
})
put("github", JSONArray())
put("deepseek", JSONArray())
put("gemini", JSONArray())
put("openai", JSONArray())
put("anthropic", JSONArray())
put("custom", JSONArray())
put("workers", JSONArray())
put("misc", JSONArray())
}

/** بارگذاری JSON خام از دیسک */
fun load(ctx: Context): JSONObject {
val prefs = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
val raw = prefs.getString(KEY_JSON, null) ?: return empty()
return try { JSONObject(raw) } catch (_: Exception) { empty() }
}

/** ذخیره JSON خام */
fun save(ctx: Context, obj: JSONObject) {
ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
.edit()
.putString(KEY_JSON, obj.toString())
.apply()
}

/** true اگر کاربر هیچ کلیدی وارد نکرده باشد */
fun isEmpty(ctx: Context): Boolean {
val cfg = load(ctx)
val sections = listOf("github","deepseek","gemini","openai","anthropic","custom","workers","misc")
for (s in sections) {
val arr = cfg.optJSONArray(s) ?: continue
if (arr.length() > 0) return false
}
return true
}

/** فقط لیست لِیبل‌ها برای نمایش وضعیت (بدون کلید واقعی) */
fun summaryMasked(ctx: Context): String {
val cfg = load(ctx)
val sb = StringBuilder()
val sections = listOf("github","deepseek","gemini","openai","anthropic","custom","workers")
for (s in sections) {
val arr = cfg.optJSONArray(s) ?: continue
if (arr.length() == 0) continue
sb.append("• {i+1}" } }
}
sb.append(labels.joinToString(", ")).append("\n")
}
return sb.toString().ifBlank { "(خالی)" }
}
}