# ☬ SHΞN™ Studio — Android Integration

راهنمای کامل اتصال Studio به فورک اپ DeepSeek.

---

## معماری

```

┌─────────────────────────────────────────────────────────┐
│  کاربر → منوی ☬ Studio                                  │
│    ↓ کلیدها را وارد می‌کند                              │
│  StudioSettingsActivity                                 │
│    ↓ (JSON)                                             │
│  SharedPreferences: shen_studio_prefs/studio_config_json│
│                                                         │
├─────────────────────────────────────────────────────────┤
│  هنگام ارسال چت:                                        │
│    baseSystemPrompt                                     │
│    ↓ StudioInjector.inject(ctx, base)                   │
│    = base + [STUDIO_CONFIG]{ ...raw keys... }           │
│    ↓                                                    │
│  ارسال به API چت                                        │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  پاسخ مدل شامل:                                         │
│    `html-panel ... `                                │
│    ↓ StudioWebViewHandler.extractPanels()               │
│    ↓ StudioWebViewHandler.showPanel()                   │
│  WebView با JavascriptInterface: StudioBridge           │
│    ↓                                                    │
│  پنل اجرا می‌شود، نتیجه → StudioBridge.onResult(payload)│
│    ↓                                                    │
│  payload به‌عنوان پیام جدید به چت برمی‌گردد              │
└─────────────────────────────────────────────────────────┘

```

---

## فایل‌ها

| فایل | نقش |
|------|-----|
| `StudioConfig.kt` | ذخیره/بارگذاری JSON در SharedPreferences |
| `StudioFieldSpec.kt` | تعریف بخش‌ها و فیلدها |
| `StudioSettingsActivity.kt` | UI تنظیمات (بدون XML) |
| `StudioInjector.kt` | تزریق `[STUDIO_CONFIG]` به system prompt |
| `StudioWebViewHandler.kt` | استخراج + اجرای پنل‌ها با پل بومی |
| `StudioActivity.kt` | نمونه‌ی اتصال به حلقه‌ی چت |
| `StudioBootReceiver.kt` | (اختیاری) |
| `studio-system-prompt.md` | پرامپت پایه که باید در system prompt اپ قرار بگیرد |
| `AndroidManifest.xml` | تکه‌های مانیفست |
| `network_security_config.xml` | تنظیمات امنیت شبکه |

---

## مراحل نصب

### ۱. کپی فایل‌های Kotlin
پکیج `com.shen.studio` را در پروژه بسازید و همه‌ی `.kt` را داخل آن بریزید.

### ۲. ادغام AndroidManifest
از فایل نمونه، `<activity>` و `<receiver>` را به مانیفست اپ اضافه کنید.

### ۳. قرار دادن system prompt
محتوای `studio-system-prompt.md` را در جایی که system prompt اپ تعریف می‌شود قرار دهید.

### ۴. تزریق به چت
در جایی که پیام کاربر را به API چت می‌فرستید:

```kotlin
val baseSystem = SystemPrompt.BASE  // پرامپت پایه اپ شما
val finalSystem = StudioInjector.inject(this, baseSystem)
// حالا finalSystem را به‌عنوان system message به API بفرست
```

### ۵. مدیریت پاسخ

پس از دریافت پاسخ مدل:

```
if (StudioWebViewHandler.hasPanel(reply)) {
    val panels = StudioWebViewHandler.extractPanels(reply)
    StudioWebViewHandler.showPanel(this, panels.last()) { payload ->
        // payload را به‌عنوان پیام جدید کاربر به چت بفرست
        sendUserMessage("[panel-result] $payload")
    }
}
```

### ۶. افزودن دکمه‌ی منو

در `MainActivity` یا `SettingsFragment` اپ:

```
buttonStudio.setOnClickListener {
    startActivity(Intent(this, StudioSettingsActivity::class.java))
}
```

---

## نحوه استفاده برای کاربر نهایی

1. اپ را باز کن → منوی **☬ Studio**
2. کلیدهای خود را وارد کن (GitHub, DeepSeek, Gemini, ...)
3. دکمه‌ی **ذخیره و بستن** را بزن
4. وارد چت شو — از این پس هر پیام با کانفیگ تو تزریق می‌شود
5. مثلاً بنویس: **«ترمینال بزن و فایل‌های seekdeep رو لیست کن»**
6. مدل یک پنل `html-panel` می‌سازد — اپ آن را در WebView اجرا می‌کند
7. نتیجه به چت برمی‌گردد

---

## جدول سرویس‌ها

| سرویس ↕▾ | توابع پل ↕▾ | فرمت کلید ↕▾ |
|---|---|---|
| −GitHub | `StudioBridge.github('/user','GET','')` | `ghp_...` یا `github_pat_...` |
| −DeepSeek | `StudioBridge.deepseek(prompt, model)` | `sk-...` |
| −Gemini | `StudioBridge.gemini(prompt, model)` | `AIza...` |
| −OpenAI | `StudioBridge.fetch('https://api.openai.com/v1/...')` | `sk-...` |
| −Anthropic | `StudioBridge.fetch('https://api.anthropic.com/v1/messages')` | `sk-ant-...` |
| −Worker | `StudioBridge.proxyFetch(...)` | — |
⚙

---

## امنیت

- کلیدها **فقط** در `SharedPreferences` دستگاه شما هستند.
- هنگام چت، کلیدها **در `[STUDIO_CONFIG]` به مدل فرستاده می‌شوند** — چون مدل باید آن‌ها را در پنل استفاده کند.
- اگر این را نمی‌خواهید: در `StudioInjector.kt` مقدار `safeMode = true` را فعال کنید — سپس فقط لیبل‌ها تزریق می‌شوند و پنل‌ها باید فقط از `StudioBridge` بومی استفاده کنند (بدون دیدن کلید).
- در هیچ لاگ/چاپی کلید کامل چاپ نشود — `StudioConfig.summaryMasked()` این را برایتان انجام می‌دهد.

---

## چه چیزی «هر بار از نو» تولید می‌شود؟

**پنل‌ها.** شما هیچ قالب ثابتی را در اپ هاردکد نمی‌کنید. مدل بر اساس کار جاری، HTML مناسب را می‌سازد. مثال:

- کاربر: «فایل‌های ریپو X را لیست کن» → مدل پنل ترمینال می‌سازد
- کاربر: «از Gemini بپرس Y چیست» → مدل پنل مشورت می‌سازد
- کاربر: «فایل Z را آپلود کن» → مدل پنل تأیید + آپلود می‌سازد

اپ فقط یک **WebView** دارد و یک **پل**. همه‌ی هوش در پرامپت و مدل است.

---

☬SHΞN™